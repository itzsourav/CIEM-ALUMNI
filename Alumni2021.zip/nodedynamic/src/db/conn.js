const mongoose = require("mongoose");

//mongoose.connect("mongodb+srv://alumniciem:sourav@sourav.uyfie.mongodb.net/myFirstDatabase?retryWrites=true&w=majority", {
    mongoose.connect("mongodb://localhost:27017/alumniciem", {
    useCreateIndex:true,
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(() => {
    console.log("connection successful");
}).catch((error) => {
    console.log(error);
})