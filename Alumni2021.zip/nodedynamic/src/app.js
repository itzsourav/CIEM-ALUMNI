const express = require("express");
const path = require("path");
//const mongoose = require("mongoose");




//const DB ="mongodb+srv://alumniciem:sourav@sourav.uyfie.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"







const DB = require("./db/conn");


const user = require("./models/usermessage");
const hbs = require("hbs");

//const mongoose = require("mongoose");

const app = express();
const port = process.env.PORT || 8000;

//mongoose.connect(DB, {
   //useNewUrlParser:true,
    //useCreateIndex:true,
    //useUnifiedTopology:true,
    //useFindAndModify:false
//}).then(() =>{
 //console.log(`connection successful`);
//}).catch((err) => console.log(`no connection`));



//setting the path
const static_path = path.join(__dirname, "../public");
const template_path = path.join(__dirname, "../templates/views");
const partials_path = path.join(__dirname, "../templates/partials");



//middleware
app.use(' /css', express.static(path.join(__dirname, "/node_modules/bootstrap/dist/css")));
app.use(' /js', express.static(path.join(__dirname, "/node_modules/bootstrap/dist/js")));
app.use(' /jq', express.static(path.join(__dirname, "/node_modules/jquery/dist")));

app.use(express.urlencoded({extended:false}))
app.use(express.static(static_path))
app.set("view engine","hbs");
app.set("views", template_path);
hbs.registerPartials(partials_path);


//routing

app.get("/",(req,res)=>{
    res.render("index");
    })
    

    app.get("/contact",(req,res)=>{
        res.render("contact");
    })

    app.get("/onedayonewish",(req,res)=>{
        res.render("onedayonewish");
    })
    
    app.get("/login",(req,res)=>{
        res.render("login");
    })

    app.get("/recommendationletter",(req,res)=>{
        res.render("recommendationletter");
    })

    app.get("/aboutus",(req,res)=>{
        res.render("aboutus");
    })



     app.post("/contact", async(req,res) => {
         try{
             res.send(req.body);
             const userData = new User(req.body);
             await UserData.save();
             res.status(201).render("index");
         } catch (error) {
             res.status(500).send(error);
         }
     })

  
app.get("/map",(req,res)=> {
        res.render("map");
        }) 
    

        app.get("/faq",(req,res)=> {
            res.render("faq");
            }) 
        
     app.get("/allevents",(req,res)=> {
         res.render("allevents");
             }) 

             app.get("/register",(req,res)=> {
                res.render("register");
                    }) 


app.post("/login", async(req, res) =>{
    try{
       const email = req.body.email;
       const password = req.body.password;


       const useremail = await user.findOne({email:email});
       if(useremail.password === password){
           res.status(201).render("index");
       }else{
          res.send("invalid login details"); 
       }
       
       




    //   res.send(useremail.password);
     // console.log(useremail);





    } catch (error) {
        res.status(400).send("invalid login details")
    }

})

//server create
app.listen(port, () => {
console.log(`server is running at port no ${port}`);
})




//password hashing


const bcrypt = require("bcryptjs");

const securePassword = async (password) => {
 
   const passwordHash = await bcrypt.hash(password, 10);
   console.log(passwordHash);

}
